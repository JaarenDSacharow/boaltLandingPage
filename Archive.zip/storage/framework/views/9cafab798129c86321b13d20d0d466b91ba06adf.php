<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto|Source+Sans+Pro:100" rel="stylesheet">

        <link href="css/app.css" rel="stylesheet" /> 

     
    </head>

<style>
html {
  font: 1.1em/1.4 Helvetica, sans-serif;
}

* { box-sizing: border-box; }

.wrapper {
  border-radius: 5px;
  margin-bottom: 2em;
}

.wrapper > div {
  border: 1px solid rgb(86,98,110);
  padding: 10px;
  color: #fff;
  font-weight: bold;
}

.multicol {
  column-width: 250px;
  column-gap: 20px;
  padding: 10px;
}

.multicol p {
  margin: 0 0 1em 0;
}

.flex {
   display: flex;
  flex-wrap: wrap;
}

.flex > * {
  flex: 1 1 250px;
  margin: 10px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  grid-gap: 20px;
  padding: 10px;
}




.main-left-pane {
    background-color: white;
}


</style>

    <body>
        <div class="full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>


<div class="wrapper flex main-left-pane">
  <div>
      <div class="boalt-logo-main">
          <img src="assets/img/BoaltLogo.png" />
    </div>

  </div>
  <div>B</div>
</div>


<h2>Grid</h2>
<div class="wrapper grid">
  <div>A</div>
  <div>B</div>
  <div>C</div>
  <div>D</div>  
</div>

</body>
</html>